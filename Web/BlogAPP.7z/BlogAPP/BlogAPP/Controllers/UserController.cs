﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BlogAPP.Models;
using BlogAPP.DAL;

namespace BlogAPP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserDAL _userDal;

        public UserController(UserDAL userDal)
        {
            _userDal = userDal;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(User user)
        {
            // Perform validation on the user object (e.g., check for required fields, password complexity, etc.)
            // You can use ModelState.IsValid to check the validation status and return appropriate error responses.

            // For the sake of simplicity, let's assume the user object is valid.
            int userId = await _userDal.CreateUserAsync(user);
            if (userId > 0)
            {
                return Ok(new { UserId = userId, Message = "User registered successfully." });
            }
            else
            {
                return BadRequest(new { Message = "Failed to register user." });
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(User user)
        {
            // Authenticate the user based on the provided credentials (e.g., username and password)
            // For the sake of simplicity, let's assume the user is authenticated.
            bool isAuthenticated = true;

            if (isAuthenticated)
            {
                // Return a token or any other necessary information for client-side authentication
                return Ok(new { Message = "User logged in successfully." });
            }
            else
            {
                return Unauthorized(new { Message = "Invalid username or password." });
            }
        }
    }
}
