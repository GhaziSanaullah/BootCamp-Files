﻿using Microsoft.AspNetCore.Mvc;
using BlogAPP.Models;
using BlogAPP.DAL;
using System.Threading.Tasks;

namespace BlogAPP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly PostDAL _postDAL;

        public PostsController(string connectionString)
        {
            _postDAL = new PostDAL(connectionString);
        }

        [HttpPost]
        public async Task<IActionResult> CreatePost(Post post)
        {
            int postId = await _postDAL.CreatePostAsync(post);
            return Ok(postId);
        }

        [HttpGet("{postID}")]
        public async Task<IActionResult> GetPost(int postID)
        {
            Post post = await _postDAL.ReadPostAsync(postID);
            if (post == null)
                return NotFound();

            return Ok(post);
        }

        [HttpPut("{postID}")]
        public async Task<IActionResult> UpdatePost(int postID, Post post)
        {
            post.PostID = postID;
            bool success = await _postDAL.UpdatePostAsync(post);
            if (!success)
                return NotFound();

            return Ok();
        }

        [HttpDelete("{postID}")]
        public async Task<IActionResult> DeletePost(int postID)
        {
            bool success = await _postDAL.DeletePostAsync(postID);
            if (!success)
                return NotFound();

            return Ok();
        }
    }
}