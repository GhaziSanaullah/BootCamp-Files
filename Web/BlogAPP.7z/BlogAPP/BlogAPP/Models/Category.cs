﻿namespace BlogAPP.Models
{
    public class Category
    {
    }
}
