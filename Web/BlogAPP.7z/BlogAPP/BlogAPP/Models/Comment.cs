﻿namespace BlogAPP.Models
{
    public class Comment
    {
    }
}
