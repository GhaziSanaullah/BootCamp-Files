﻿using BlogAPP.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace BlogAPP.DAL
{
    public class PostDAL
    {
        private readonly string _connectionString;

        public PostDAL(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Create a new post in the database
        public async Task<int> CreatePostAsync(Post post)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "INSERT INTO Posts (UserID, CategoryID, Title, Content, CreatedAt) " +
                               "VALUES (@UserID, @CategoryID, @Title, @Content, @CreatedAt); " +
                               "SELECT SCOPE_IDENTITY();";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", post.UserID);
                command.Parameters.AddWithValue("@CategoryID", post.CategoryID);
                command.Parameters.AddWithValue("@Title", post.Title);
                command.Parameters.AddWithValue("@Content", post.Content);
                command.Parameters.AddWithValue("@CreatedAt", post.CreatedAt);

                await connection.OpenAsync();
                return Convert.ToInt32(await command.ExecuteScalarAsync());
            }
        }

        // Read a single post from the database by PostID
        public async Task<Post> ReadPostAsync(int postID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT * FROM Posts WHERE PostID = @PostID;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PostID", postID);

                await connection.OpenAsync();
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        return MapPostFromReader(reader);
                    }
                }
            }

            return null;
        }

        // Update an existing post in the database
        public async Task<bool> UpdatePostAsync(Post post)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "UPDATE Posts SET UserID = @UserID, CategoryID = @CategoryID, " +
                               "Title = @Title, Content = @Content, CreatedAt = @CreatedAt " +
                               "WHERE PostID = @PostID;";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", post.UserID);
                command.Parameters.AddWithValue("@CategoryID", post.CategoryID);
                command.Parameters.AddWithValue("@Title", post.Title);
                command.Parameters.AddWithValue("@Content", post.Content);
                command.Parameters.AddWithValue("@CreatedAt", post.CreatedAt);
                command.Parameters.AddWithValue("@PostID", post.PostID);

                await connection.OpenAsync();
                return await command.ExecuteNonQueryAsync() > 0;
            }
        }

        // Delete a post from the database by PostID
        public async Task<bool> DeletePostAsync(int postID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "DELETE FROM Posts WHERE PostID = @PostID;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PostID", postID);

                await connection.OpenAsync();
                return await command.ExecuteNonQueryAsync() > 0;
            }
        }

        // Helper method to map the data from SqlDataReader to a Post object
        private Post MapPostFromReader(SqlDataReader reader)
        {
            return new Post
            {
                PostID = Convert.ToInt32(reader["PostID"]),
                UserID = Convert.ToInt32(reader["UserID"]),
                CategoryID = Convert.ToInt32(reader["CategoryID"]),
                Title = Convert.ToString(reader["Title"]),
                Content = Convert.ToString(reader["Content"]),
                CreatedAt = Convert.ToDateTime(reader["CreatedAt"])
            };
        }
    }
}
